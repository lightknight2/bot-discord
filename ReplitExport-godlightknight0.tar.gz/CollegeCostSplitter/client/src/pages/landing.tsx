import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { 
  DollarSign, 
  Users, 
  MessageSquare, 
  TrendingUp,
  BookOpen,
  Coffee,
  Home,
  Car
} from "lucide-react";

export default function Landing() {
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-gradient-to-r from-primary to-secondary rounded-xl flex items-center justify-center">
                <DollarSign className="w-6 h-6 text-white" />
              </div>
              <h1 className="text-2xl font-bold text-gray-900">SplitSmart</h1>
            </div>
            <Button asChild>
              <a href="/api/login">Get Started</a>
            </Button>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="text-center">
          <h2 className="text-4xl font-bold text-gray-900 sm:text-5xl">
            Smart Expense Tracking for 
            <span className="text-primary"> College Students</span>
          </h2>
          <p className="mt-6 text-xl text-gray-600 max-w-3xl mx-auto">
            Track your expenses, split bills with roommates, and connect with other students. 
            Take control of your finances while building lasting friendships.
          </p>
          <div className="mt-8">
            <Button size="lg" asChild>
              <a href="/api/login">Start Managing Your Money</a>
            </Button>
          </div>
        </div>
      </section>

      {/* Features Grid */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          <Card>
            <CardHeader>
              <div className="w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center mb-4">
                <DollarSign className="w-6 h-6 text-primary" />
              </div>
              <CardTitle>Expense Tracking</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600">
                Easily track all your expenses with smart categorization for textbooks, food, entertainment, and more.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <div className="w-12 h-12 bg-secondary/10 rounded-xl flex items-center justify-center mb-4">
                <Users className="w-6 h-6 text-secondary" />
              </div>
              <CardTitle>Bill Splitting</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600">
                Split bills with roommates effortlessly. Keep track of who owes what and settle up easily.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <div className="w-12 h-12 bg-accent/10 rounded-xl flex items-center justify-center mb-4">
                <MessageSquare className="w-6 h-6 text-accent" />
              </div>
              <CardTitle>Community</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600">
                Connect with other students, share money-saving tips, and find people to split bulk purchases.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <div className="w-12 h-12 bg-warning/10 rounded-xl flex items-center justify-center mb-4">
                <TrendingUp className="w-6 h-6 text-warning" />
              </div>
              <CardTitle>Analytics</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600">
                Understand your spending patterns with clear insights and helpful budgeting suggestions.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <div className="w-12 h-12 bg-green-100 rounded-xl flex items-center justify-center mb-4">
                <BookOpen className="w-6 h-6 text-green-600" />
              </div>
              <CardTitle>Student Categories</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600">
                Pre-built categories for textbooks, dining hall, dorm supplies, and other student essentials.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <div className="w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center mb-4">
                <Home className="w-6 h-6 text-blue-600" />
              </div>
              <CardTitle>Roommate Groups</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600">
                Create groups for your apartment, dorm floor, or friend circle to manage shared expenses.
              </p>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Popular Categories */}
      <section className="bg-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h3 className="text-3xl font-bold text-gray-900">Popular Student Expense Categories</h3>
            <p className="mt-4 text-gray-600">Track the expenses that matter most to students</p>
          </div>
          
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            <div className="text-center">
              <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-3">
                <Coffee className="w-8 h-8 text-red-600" />
              </div>
              <h4 className="font-medium text-gray-900">Food & Dining</h4>
            </div>
            
            <div className="text-center">
              <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-3">
                <BookOpen className="w-8 h-8 text-blue-600" />
              </div>
              <h4 className="font-medium text-gray-900">Textbooks</h4>
            </div>
            
            <div className="text-center">
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-3">
                <Car className="w-8 h-8 text-green-600" />
              </div>
              <h4 className="font-medium text-gray-900">Transportation</h4>
            </div>
            
            <div className="text-center">
              <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-3">
                <Home className="w-8 h-8 text-purple-600" />
              </div>
              <h4 className="font-medium text-gray-900">Housing</h4>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-primary py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h3 className="text-3xl font-bold text-white">Ready to Take Control of Your Finances?</h3>
          <p className="mt-4 text-xl text-primary-foreground/90">
            Join thousands of students who are already managing their money smarter.
          </p>
          <Button size="lg" variant="secondary" className="mt-8" asChild>
            <a href="/api/login">Get Started for Free</a>
          </Button>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-white border-t border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="flex items-center justify-center">
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 bg-gradient-to-r from-primary to-secondary rounded-lg flex items-center justify-center">
                <DollarSign className="w-5 h-5 text-white" />
              </div>
              <span className="text-gray-900 font-medium">SplitSmart</span>
              <span className="text-gray-500">- Smart money management for students</span>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
