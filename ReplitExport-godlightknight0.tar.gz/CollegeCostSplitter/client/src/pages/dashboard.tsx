import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { 
  DollarSign, 
  Users, 
  TrendingUp, 
  Plus,
  ShoppingCart,
  BookOpen,
  Film,
  Clock,
  Heart,
  MessageSquare
} from "lucide-react";
import { useState } from "react";
import AddExpenseForm from "@/components/expense/add-expense-form";
import CreateGroupForm from "@/components/group/create-group-form";

export default function Dashboard() {
  const [showAddExpense, setShowAddExpense] = useState(false);
  const [showCreateGroup, setShowCreateGroup] = useState(false);

  const { data: stats, isLoading: statsLoading } = useQuery({
    queryKey: ["/api/dashboard/stats"],
  });

  const { data: expenses, isLoading: expensesLoading } = useQuery({
    queryKey: ["/api/expenses"],
  });

  const { data: groups, isLoading: groupsLoading } = useQuery({
    queryKey: ["/api/groups"],
  });

  const { data: communityPosts, isLoading: postsLoading } = useQuery({
    queryKey: ["/api/community/posts"],
  });

  const recentExpenses = expenses?.slice(0, 3) || [];
  const recentPosts = communityPosts?.slice(0, 2) || [];

  const getCategoryIcon = (categoryId: number) => {
    switch (categoryId) {
      case 1: return <ShoppingCart className="w-5 h-5 text-red-600" />;
      case 2: return <BookOpen className="w-5 h-5 text-blue-600" />;
      case 3: return <Film className="w-5 h-5 text-green-600" />;
      default: return <DollarSign className="w-5 h-5 text-gray-600" />;
    }
  };

  const getCategoryColor = (categoryId: number) => {
    switch (categoryId) {
      case 1: return "bg-red-100";
      case 2: return "bg-blue-100";
      case 3: return "bg-green-100";
      default: return "bg-gray-100";
    }
  };

  if (statsLoading) {
    return (
      <div className="p-4 lg:p-6">
        <div className="mb-6">
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Dashboard</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {[...Array(4)].map((_, i) => (
              <Card key={i}>
                <CardContent className="p-6">
                  <Skeleton className="h-20" />
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="p-4 lg:p-6">
      {/* Header */}
      <div className="mb-6">
        <h2 className="text-2xl font-bold text-gray-900 mb-4">Dashboard</h2>
        
        {/* Summary Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">This Month</p>
                  <p className="text-2xl font-bold text-gray-900">
                    ${stats?.monthlyTotal?.toFixed(2) || "0.00"}
                  </p>
                </div>
                <div className="w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center">
                  <DollarSign className="w-6 h-6 text-primary" />
                </div>
              </div>
              <div className="mt-4">
                <span className="text-accent text-sm font-medium">Track your spending</span>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Pending Splits</p>
                  <p className="text-2xl font-bold text-gray-900">
                    ${stats?.pendingSplits?.toFixed(2) || "0.00"}
                  </p>
                </div>
                <div className="w-12 h-12 bg-warning/10 rounded-xl flex items-center justify-center">
                  <Clock className="w-6 h-6 text-warning" />
                </div>
              </div>
              <div className="mt-4">
                <span className="text-warning text-sm font-medium">
                  {stats?.pendingSplits > 0 ? "Settle up soon" : "All caught up!"}
                </span>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Monthly Budget</p>
                  <p className="text-2xl font-bold text-gray-900">$500.00</p>
                </div>
                <div className="w-12 h-12 bg-accent/10 rounded-xl flex items-center justify-center">
                  <TrendingUp className="w-6 h-6 text-accent" />
                </div>
              </div>
              <div className="mt-4">
                <span className="text-accent text-sm font-medium">
                  {stats?.monthlyTotal && stats.monthlyTotal < 500 ? "On track!" : "Review spending"}
                </span>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Active Groups</p>
                  <p className="text-2xl font-bold text-gray-900">{stats?.activeGroups || 0}</p>
                </div>
                <div className="w-12 h-12 bg-secondary/10 rounded-xl flex items-center justify-center">
                  <Users className="w-6 h-6 text-secondary" />
                </div>
              </div>
              <div className="mt-4">
                <span className="text-secondary text-sm font-medium">
                  {groups?.length > 0 ? `${groups.length} total groups` : "Create your first group"}
                </span>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Recent Expenses & Quick Actions */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
        {/* Recent Expenses */}
        <Card className="lg:col-span-2">
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle>Recent Expenses</CardTitle>
              <Button variant="ghost" size="sm">View All</Button>
            </div>
          </CardHeader>
          <CardContent>
            {expensesLoading ? (
              <div className="space-y-4">
                {[...Array(3)].map((_, i) => (
                  <Skeleton key={i} className="h-16" />
                ))}
              </div>
            ) : recentExpenses.length > 0 ? (
              <div className="space-y-4">
                {recentExpenses.map((expense: any) => (
                  <div key={expense.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                    <div className="flex items-center space-x-3">
                      <div className={`w-10 h-10 rounded-full flex items-center justify-center ${getCategoryColor(expense.categoryId)}`}>
                        {getCategoryIcon(expense.categoryId)}
                      </div>
                      <div>
                        <p className="font-medium text-gray-900">{expense.title}</p>
                        <p className="text-sm text-gray-500">
                          {new Date(expense.date).toLocaleDateString()}
                        </p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="font-semibold text-gray-900">${Number(expense.amount).toFixed(2)}</p>
                      <Badge variant="secondary" className="text-xs">
                        Category {expense.categoryId}
                      </Badge>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-8">
                <DollarSign className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-500">No expenses yet. Add your first expense!</p>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Quick Actions */}
        <Card>
          <CardHeader>
            <CardTitle>Quick Actions</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <Button 
              className="w-full" 
              onClick={() => setShowAddExpense(true)}
            >
              <Plus className="w-5 h-5 mr-2" />
              Add Expense
            </Button>
            <Button 
              variant="secondary" 
              className="w-full"
              onClick={() => setShowCreateGroup(true)}
            >
              <Users className="w-5 h-5 mr-2" />
              Create Group
            </Button>
            <Button variant="outline" className="w-full">
              <TrendingUp className="w-5 h-5 mr-2" />
              View Analytics
            </Button>
          </CardContent>
        </Card>
      </div>

      {/* Active Groups */}
      <Card className="mb-6">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle>Active Groups</CardTitle>
            <Button variant="ghost" size="sm">Manage</Button>
          </div>
        </CardHeader>
        <CardContent>
          {groupsLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {[...Array(2)].map((_, i) => (
                <Skeleton key={i} className="h-24" />
              ))}
            </div>
          ) : groups && groups.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {groups.map((group: any) => (
                <Card key={group.id} className="border-2">
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center space-x-3">
                        <div className="w-8 h-8 bg-gradient-to-r from-blue-400 to-purple-500 rounded-lg"></div>
                        <div>
                          <h4 className="font-medium text-gray-900">{group.name}</h4>
                          <p className="text-sm text-gray-500">Active group</p>
                        </div>
                      </div>
                      <Badge className="bg-accent/10 text-accent">Active</Badge>
                    </div>
                    <div className="text-sm text-gray-600">
                      Click to view details and manage expenses
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <div className="text-center py-8">
              <Users className="w-12 h-12 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-500">No groups yet. Create your first group!</p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Community Feed */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle>Community Feed</CardTitle>
            <Button variant="ghost" size="sm">View All</Button>
          </div>
        </CardHeader>
        <CardContent>
          {postsLoading ? (
            <div className="space-y-4">
              {[...Array(2)].map((_, i) => (
                <Skeleton key={i} className="h-20" />
              ))}
            </div>
          ) : recentPosts.length > 0 ? (
            <div className="space-y-4">
              {recentPosts.map((post: any) => (
                <div key={post.id} className="border border-gray-100 rounded-lg p-4">
                  <div className="flex items-start space-x-3">
                    <div className="w-10 h-10 bg-gradient-to-r from-pink-400 to-red-400 rounded-full flex-shrink-0"></div>
                    <div className="flex-1">
                      <div className="flex items-center space-x-2 mb-2">
                        <p className="font-medium text-gray-900">
                          {post.user.firstName} {post.user.lastName}
                        </p>
                        <span className="text-sm text-gray-500">
                          • {new Date(post.createdAt).toLocaleDateString()}
                        </span>
                      </div>
                      <p className="text-gray-700 text-sm mb-3">{post.content}</p>
                      <div className="flex items-center space-x-4 text-sm text-gray-500">
                        <button className="flex items-center space-x-1 hover:text-primary">
                          <Heart className="w-4 h-4" />
                          <span>{post.likeCount}</span>
                        </button>
                        <button className="flex items-center space-x-1 hover:text-primary">
                          <MessageSquare className="w-4 h-4" />
                          <span>Reply</span>
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-8">
              <MessageSquare className="w-12 h-12 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-500">No community posts yet. Be the first to share!</p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Modals */}
      {showAddExpense && (
        <AddExpenseForm 
          onClose={() => setShowAddExpense(false)}
          onSuccess={() => setShowAddExpense(false)}
        />
      )}

      {showCreateGroup && (
        <CreateGroupForm 
          onClose={() => setShowCreateGroup(false)}
          onSuccess={() => setShowCreateGroup(false)}
        />
      )}
    </div>
  );
}
