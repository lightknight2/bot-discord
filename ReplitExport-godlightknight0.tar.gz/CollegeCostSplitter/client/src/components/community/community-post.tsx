import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Heart, MessageSquare, MoreHorizontal } from "lucide-react";
import { cn } from "@/lib/utils";
import { useAuth } from "@/hooks/useAuth";

interface CommunityPostProps {
  post: {
    id: number;
    content: string;
    createdAt: string;
    user: {
      id: string;
      firstName?: string;
      lastName?: string;
      profileImageUrl?: string;
    };
    likes: Array<{
      id: number;
      userId: string;
    }>;
    likeCount: number;
  };
  onLike: () => void;
}

export default function CommunityPost({ post, onLike }: CommunityPostProps) {
  const { user } = useAuth();
  const [showComments, setShowComments] = useState(false);

  const isLiked = post.likes.some(like => like.userId === user?.id);
  const userName = post.user.firstName && post.user.lastName 
    ? `${post.user.firstName} ${post.user.lastName}`
    : post.user.firstName || 'Anonymous User';

  const formatTimeAgo = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffInMs = now.getTime() - date.getTime();
    const diffInHours = Math.floor(diffInMs / (1000 * 60 * 60));
    const diffInDays = Math.floor(diffInHours / 24);

    if (diffInHours < 1) {
      return 'Just now';
    } else if (diffInHours < 24) {
      return `${diffInHours}h ago`;
    } else if (diffInDays < 7) {
      return `${diffInDays}d ago`;
    } else {
      return date.toLocaleDateString();
    }
  };

  return (
    <div className="border border-gray-100 rounded-lg p-6 hover:border-gray-200 transition-colors">
      <div className="flex items-start space-x-4">
        {/* Avatar */}
        <div className="flex-shrink-0">
          {post.user.profileImageUrl ? (
            <img
              src={post.user.profileImageUrl}
              alt={userName}
              className="w-10 h-10 rounded-full object-cover"
            />
          ) : (
            <div className="w-10 h-10 bg-gradient-to-r from-pink-400 to-red-400 rounded-full flex items-center justify-center">
              <span className="text-white font-medium text-sm">
                {userName.charAt(0).toUpperCase()}
              </span>
            </div>
          )}
        </div>

        {/* Post Content */}
        <div className="flex-1 min-w-0">
          {/* Header */}
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center space-x-2">
              <p className="font-medium text-gray-900">{userName}</p>
              <span className="text-sm text-gray-500">
                • {formatTimeAgo(post.createdAt)}
              </span>
            </div>
            <Button variant="ghost" size="sm">
              <MoreHorizontal className="w-4 h-4" />
            </Button>
          </div>

          {/* Content */}
          <p className="text-gray-700 mb-4 whitespace-pre-wrap">
            {post.content}
          </p>

          {/* Actions */}
          <div className="flex items-center space-x-6">
            <Button
              variant="ghost"
              size="sm"
              onClick={onLike}
              className={cn(
                "flex items-center space-x-2 hover:text-red-500 transition-colors",
                isLiked && "text-red-500"
              )}
            >
              <Heart className={cn("w-4 h-4", isLiked && "fill-current")} />
              <span>{post.likeCount}</span>
            </Button>

            <Button
              variant="ghost"
              size="sm"
              onClick={() => setShowComments(!showComments)}
              className="flex items-center space-x-2 hover:text-blue-500 transition-colors"
            >
              <MessageSquare className="w-4 h-4" />
              <span>Reply</span>
            </Button>
          </div>

          {/* Comments Section */}
          {showComments && (
            <div className="mt-4 pl-4 border-l-2 border-gray-100">
              <div className="text-sm text-gray-500">
                Comments feature coming soon...
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
