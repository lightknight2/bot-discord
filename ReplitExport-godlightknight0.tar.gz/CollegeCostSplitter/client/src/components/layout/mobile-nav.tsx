import { useLocation } from "wouter";
import { cn } from "@/lib/utils";
import { 
  LayoutDashboard, 
  Receipt, 
  Users, 
  MessageSquare, 
  User,
  Plus
} from "lucide-react";
import { useState } from "react";
import AddExpenseForm from "@/components/expense/add-expense-form";

const navigation = [
  { name: "Dashboard", href: "/", icon: LayoutDashboard },
  { name: "Expenses", href: "/expenses", icon: Receipt },
  { name: "Groups", href: "/groups", icon: Users },
  { name: "Community", href: "/community", icon: MessageSquare },
  { name: "Profile", href: "/profile", icon: User },
];

export default function MobileNav() {
  const [location, setLocation] = useLocation();
  const [showAddExpense, setShowAddExpense] = useState(false);

  return (
    <>
      {/* Bottom Navigation */}
      <nav className="lg:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 z-50">
        <div className="grid grid-cols-5 h-16">
          {navigation.map((item) => {
            const isActive = location === item.href;
            return (
              <button
                key={item.name}
                onClick={() => setLocation(item.href)}
                className={cn(
                  "flex flex-col items-center justify-center transition-colors",
                  isActive ? "text-primary" : "text-gray-400"
                )}
              >
                <item.icon className="w-5 h-5" />
                <span className="text-xs mt-1">{item.name}</span>
              </button>
            );
          })}
        </div>
      </nav>

      {/* Floating Action Button */}
      <button 
        onClick={() => setShowAddExpense(true)}
        className="lg:hidden fixed bottom-20 right-4 w-14 h-14 bg-primary text-white rounded-full shadow-lg flex items-center justify-center hover:bg-primary/90 transition-colors z-40"
      >
        <Plus className="w-6 h-6" />
      </button>

      {/* Mobile Header */}
      <header className="bg-white shadow-sm border-b border-gray-200 lg:hidden">
        <div className="px-4 py-3 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 bg-gradient-to-r from-primary to-secondary rounded-lg flex items-center justify-center">
              <Receipt className="w-5 h-5 text-white" />
            </div>
            <h1 className="text-xl font-bold text-gray-900">SplitSmart</h1>
          </div>
          <div className="flex items-center space-x-2">
            <button 
              onClick={() => window.location.href = '/api/logout'}
              className="p-2 text-gray-600 hover:text-gray-900"
            >
              <User className="w-6 h-6" />
            </button>
          </div>
        </div>
      </header>

      {/* Add bottom padding to main content for mobile nav */}
      <style jsx global>{`
        @media (max-width: 1024px) {
          body {
            padding-bottom: 4rem;
          }
        }
      `}</style>

      {/* Add Expense Modal */}
      {showAddExpense && (
        <AddExpenseForm 
          onClose={() => setShowAddExpense(false)}
          onSuccess={() => setShowAddExpense(false)}
        />
      )}
    </>
  );
}
