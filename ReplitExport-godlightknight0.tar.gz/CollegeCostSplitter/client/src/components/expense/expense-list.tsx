import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { 
  ShoppingCart,
  BookOpen,
  Film,
  Car,
  Home,
  DollarSign,
  Edit,
  Trash2
} from "lucide-react";

interface Expense {
  id: number;
  title: string;
  amount: string;
  categoryId: number;
  description?: string;
  date: string;
}

interface Category {
  id: number;
  name: string;
  color: string;
  icon?: string;
}

interface ExpenseListProps {
  expenses: Expense[];
  categories: Category[];
}

export default function ExpenseList({ expenses, categories }: ExpenseListProps) {
  const getCategoryIcon = (categoryId: number) => {
    switch (categoryId) {
      case 1: return <ShoppingCart className="w-5 h-5 text-red-600" />;
      case 2: return <BookOpen className="w-5 h-5 text-blue-600" />;
      case 3: return <Film className="w-5 h-5 text-green-600" />;
      case 4: return <Car className="w-5 h-5 text-purple-600" />;
      case 5: return <Home className="w-5 h-5 text-orange-600" />;
      default: return <DollarSign className="w-5 h-5 text-gray-600" />;
    }
  };

  const getCategoryColor = (categoryId: number) => {
    switch (categoryId) {
      case 1: return "bg-red-100";
      case 2: return "bg-blue-100";
      case 3: return "bg-green-100";
      case 4: return "bg-purple-100";
      case 5: return "bg-orange-100";
      default: return "bg-gray-100";
    }
  };

  const getCategoryName = (categoryId: number) => {
    switch (categoryId) {
      case 1: return "Food & Dining";
      case 2: return "Textbooks";
      case 3: return "Entertainment";
      case 4: return "Transportation";
      case 5: return "Housing";
      default: return "Other";
    }
  };

  if (expenses.length === 0) {
    return (
      <div className="text-center py-8">
        <DollarSign className="w-12 h-12 text-gray-400 mx-auto mb-4" />
        <p className="text-gray-500">No expenses found</p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {expenses.map((expense) => (
        <div
          key={expense.id}
          className="flex items-center justify-between p-4 border border-gray-200 rounded-lg hover:border-primary/20 transition-colors"
        >
          <div className="flex items-center space-x-4">
            <div className={`w-12 h-12 rounded-full flex items-center justify-center ${getCategoryColor(expense.categoryId)}`}>
              {getCategoryIcon(expense.categoryId)}
            </div>
            <div className="min-w-0 flex-1">
              <h3 className="font-medium text-gray-900 truncate">
                {expense.title}
              </h3>
              <div className="flex items-center space-x-2 mt-1">
                <p className="text-sm text-gray-500">
                  {new Date(expense.date).toLocaleDateString()}
                </p>
                <Badge variant="secondary" className="text-xs">
                  {getCategoryName(expense.categoryId)}
                </Badge>
              </div>
              {expense.description && (
                <p className="text-sm text-gray-600 mt-1 line-clamp-1">
                  {expense.description}
                </p>
              )}
            </div>
          </div>

          <div className="flex items-center space-x-4">
            <div className="text-right">
              <p className="font-semibold text-gray-900">
                ${Number(expense.amount).toFixed(2)}
              </p>
            </div>
            <div className="flex items-center space-x-1">
              <Button variant="ghost" size="sm">
                <Edit className="w-4 h-4" />
              </Button>
              <Button variant="ghost" size="sm">
                <Trash2 className="w-4 h-4 text-red-600" />
              </Button>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}
