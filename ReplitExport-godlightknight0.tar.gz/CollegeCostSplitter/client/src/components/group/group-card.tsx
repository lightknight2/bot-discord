import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Users, DollarSign, Plus } from "lucide-react";

interface Group {
  id: number;
  name: string;
  description?: string;
  createdBy: string;
  createdAt: string;
}

interface GroupCardProps {
  group: Group;
}

export default function GroupCard({ group }: GroupCardProps) {
  const { data: balance } = useQuery({
    queryKey: ["/api/groups", group.id, "balance"],
  });

  const { data: members } = useQuery({
    queryKey: ["/api/groups", group.id, "members"],
  });

  const balanceAmount = balance?.balance || 0;
  const memberCount = members?.length || 0;

  return (
    <Card className="hover:border-primary/20 transition-colors cursor-pointer">
      <CardContent className="p-6">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-gradient-to-r from-blue-400 to-purple-500 rounded-xl flex items-center justify-center">
              <Users className="w-5 h-5 text-white" />
            </div>
            <div>
              <h3 className="font-semibold text-gray-900">{group.name}</h3>
              <p className="text-sm text-gray-500">{memberCount} members</p>
            </div>
          </div>
          <Badge variant="secondary" className="bg-accent/10 text-accent">
            Active
          </Badge>
        </div>

        {group.description && (
          <p className="text-sm text-gray-600 mb-4 line-clamp-2">
            {group.description}
          </p>
        )}

        <div className="space-y-3">
          <div className="flex justify-between items-center">
            <span className="text-sm text-gray-600">Your balance:</span>
            <span className={`font-medium ${
              balanceAmount > 0 ? 'text-accent' : 
              balanceAmount < 0 ? 'text-red-600' : 
              'text-gray-900'
            }`}>
              {balanceAmount > 0 ? '+' : ''}${Math.abs(balanceAmount).toFixed(2)}
            </span>
          </div>
          
          <div className="flex justify-between items-center">
            <span className="text-sm text-gray-600">Status:</span>
            <span className="text-sm font-medium text-gray-900">
              {balanceAmount === 0 ? 'Settled up' : 
               balanceAmount > 0 ? 'Owed money' : 
               'Owes money'}
            </span>
          </div>
        </div>

        <div className="flex gap-2 mt-4">
          <Button size="sm" variant="outline" className="flex-1">
            <DollarSign className="w-4 h-4 mr-1" />
            View Expenses
          </Button>
          <Button size="sm" className="flex-1">
            <Plus className="w-4 h-4 mr-1" />
            Add Expense
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
