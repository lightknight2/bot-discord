import {
  users,
  expenses,
  categories,
  groups,
  groupMembers,
  groupExpenses,
  expenseSplits,
  communityPosts,
  postLikes,
  type User,
  type UpsertUser,
  type InsertExpense,
  type Expense,
  type Category,
  type InsertGroup,
  type Group,
  type GroupMember,
  type InsertGroupExpense,
  type GroupExpense,
  type ExpenseSplit,
  type InsertCommunityPost,
  type CommunityPost,
  type PostLike,
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, sql, and } from "drizzle-orm";

export interface IStorage {
  // User operations (mandatory for Replit Auth)
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  
  // Category operations
  getCategories(): Promise<Category[]>;
  
  // Expense operations
  getUserExpenses(userId: string): Promise<Expense[]>;
  createExpense(expense: InsertExpense): Promise<Expense>;
  updateExpense(id: number, expense: Partial<InsertExpense>): Promise<Expense>;
  deleteExpense(id: number): Promise<void>;
  
  // Group operations
  getUserGroups(userId: string): Promise<Group[]>;
  createGroup(group: InsertGroup): Promise<Group>;
  joinGroup(groupId: number, userId: string): Promise<void>;
  getGroupMembers(groupId: number): Promise<GroupMember[]>;
  
  // Group expense operations
  getGroupExpenses(groupId: number): Promise<GroupExpense[]>;
  createGroupExpense(expense: InsertGroupExpense, memberIds: string[]): Promise<GroupExpense>;
  getUserBalanceInGroup(userId: string, groupId: number): Promise<number>;
  
  // Community operations
  getCommunityPosts(): Promise<(CommunityPost & { user: User; likes: PostLike[]; likeCount: number })[]>;
  createCommunityPost(post: InsertCommunityPost): Promise<CommunityPost>;
  togglePostLike(postId: number, userId: string): Promise<void>;
  
  // Dashboard analytics
  getUserMonthlyTotal(userId: string): Promise<number>;
  getUserPendingSplits(userId: string): Promise<number>;
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  // Category operations
  async getCategories(): Promise<Category[]> {
    return await db.select().from(categories);
  }

  // Expense operations
  async getUserExpenses(userId: string): Promise<Expense[]> {
    return await db
      .select()
      .from(expenses)
      .where(eq(expenses.userId, userId))
      .orderBy(desc(expenses.date));
  }

  async createExpense(expense: InsertExpense): Promise<Expense> {
    const [newExpense] = await db.insert(expenses).values(expense).returning();
    return newExpense;
  }

  async updateExpense(id: number, expense: Partial<InsertExpense>): Promise<Expense> {
    const [updatedExpense] = await db
      .update(expenses)
      .set(expense)
      .where(eq(expenses.id, id))
      .returning();
    return updatedExpense;
  }

  async deleteExpense(id: number): Promise<void> {
    await db.delete(expenses).where(eq(expenses.id, id));
  }

  // Group operations
  async getUserGroups(userId: string): Promise<Group[]> {
    const userGroups = await db
      .select({
        id: groups.id,
        name: groups.name,
        description: groups.description,
        createdBy: groups.createdBy,
        createdAt: groups.createdAt,
      })
      .from(groups)
      .innerJoin(groupMembers, eq(groups.id, groupMembers.groupId))
      .where(eq(groupMembers.userId, userId));
    
    return userGroups;
  }

  async createGroup(group: InsertGroup): Promise<Group> {
    const [newGroup] = await db.insert(groups).values(group).returning();
    
    // Add creator as member
    await db.insert(groupMembers).values({
      groupId: newGroup.id,
      userId: group.createdBy,
    });
    
    return newGroup;
  }

  async joinGroup(groupId: number, userId: string): Promise<void> {
    await db.insert(groupMembers).values({
      groupId,
      userId,
    });
  }

  async getGroupMembers(groupId: number): Promise<GroupMember[]> {
    return await db
      .select()
      .from(groupMembers)
      .where(eq(groupMembers.groupId, groupId));
  }

  // Group expense operations
  async getGroupExpenses(groupId: number): Promise<GroupExpense[]> {
    return await db
      .select()
      .from(groupExpenses)
      .where(eq(groupExpenses.groupId, groupId))
      .orderBy(desc(groupExpenses.date));
  }

  async createGroupExpense(expense: InsertGroupExpense, memberIds: string[]): Promise<GroupExpense> {
    const [newExpense] = await db.insert(groupExpenses).values(expense).returning();
    
    // Create splits for each member
    const splitAmount = Number(expense.amount) / memberIds.length;
    const splits = memberIds.map(userId => ({
      groupExpenseId: newExpense.id,
      userId,
      amount: splitAmount.toString(),
      settled: userId === expense.paidBy, // Mark as settled for the person who paid
    }));
    
    await db.insert(expenseSplits).values(splits);
    
    return newExpense;
  }

  async getUserBalanceInGroup(userId: string, groupId: number): Promise<number> {
    // Calculate how much user owes others minus how much others owe user
    const result = await db
      .select({
        balance: sql<number>`
          COALESCE(SUM(
            CASE 
              WHEN ${expenseSplits.userId} = ${userId} AND ${expenseSplits.settled} = false 
              THEN -${expenseSplits.amount}
              WHEN ${groupExpenses.paidBy} = ${userId} AND ${expenseSplits.userId} != ${userId} AND ${expenseSplits.settled} = false
              THEN ${expenseSplits.amount}
              ELSE 0
            END
          ), 0)
        `
      })
      .from(expenseSplits)
      .innerJoin(groupExpenses, eq(expenseSplits.groupExpenseId, groupExpenses.id))
      .where(eq(groupExpenses.groupId, groupId));
    
    return result[0]?.balance || 0;
  }

  // Community operations
  async getCommunityPosts(): Promise<(CommunityPost & { user: User; likes: PostLike[]; likeCount: number })[]> {
    const postsWithData = await db
      .select({
        id: communityPosts.id,
        userId: communityPosts.userId,
        content: communityPosts.content,
        createdAt: communityPosts.createdAt,
        user: {
          id: users.id,
          email: users.email,
          firstName: users.firstName,
          lastName: users.lastName,
          profileImageUrl: users.profileImageUrl,
          createdAt: users.createdAt,
          updatedAt: users.updatedAt,
        },
        likeCount: sql<number>`COUNT(${postLikes.id})`.as('likeCount'),
      })
      .from(communityPosts)
      .innerJoin(users, eq(communityPosts.userId, users.id))
      .leftJoin(postLikes, eq(communityPosts.id, postLikes.postId))
      .groupBy(communityPosts.id, users.id)
      .orderBy(desc(communityPosts.createdAt));

    // Get likes for each post
    const postsWithLikes = await Promise.all(
      postsWithData.map(async (post) => {
        const likes = await db
          .select()
          .from(postLikes)
          .where(eq(postLikes.postId, post.id));
        
        return {
          ...post,
          likes,
        };
      })
    );

    return postsWithLikes;
  }

  async createCommunityPost(post: InsertCommunityPost): Promise<CommunityPost> {
    const [newPost] = await db.insert(communityPosts).values(post).returning();
    return newPost;
  }

  async togglePostLike(postId: number, userId: string): Promise<void> {
    const existingLike = await db
      .select()
      .from(postLikes)
      .where(and(eq(postLikes.postId, postId), eq(postLikes.userId, userId)));

    if (existingLike.length > 0) {
      await db
        .delete(postLikes)
        .where(and(eq(postLikes.postId, postId), eq(postLikes.userId, userId)));
    } else {
      await db.insert(postLikes).values({ postId, userId });
    }
  }

  // Dashboard analytics
  async getUserMonthlyTotal(userId: string): Promise<number> {
    const result = await db
      .select({
        total: sql<number>`COALESCE(SUM(${expenses.amount}), 0)`,
      })
      .from(expenses)
      .where(
        and(
          eq(expenses.userId, userId),
          sql`${expenses.date} >= date_trunc('month', CURRENT_DATE)`
        )
      );

    return Number(result[0]?.total || 0);
  }

  async getUserPendingSplits(userId: string): Promise<number> {
    const result = await db
      .select({
        total: sql<number>`COALESCE(SUM(${expenseSplits.amount}), 0)`,
      })
      .from(expenseSplits)
      .where(
        and(
          eq(expenseSplits.userId, userId),
          eq(expenseSplits.settled, false)
        )
      );

    return Number(result[0]?.total || 0);
  }
}

export const storage = new DatabaseStorage();
