import discord
from discord.ext import commands
from discord import app_commands
import asyncio
import os

# Si tu souhaites garder ton projet actif, assure-toi de démarrer le serveur web
# (à utiliser avec UptimeRobot). Décommente le code suivant si tu utilises keep_alive.py.
# from keep_alive import keep_alive
# keep_alive()

# Création du bot avec le préfixe "+"
bot = commands.Bot(command_prefix="+", intents=discord.Intents.all())
bot.remove_command("help")  # Suppression de l'aide par défaut

###########################
#  MODULE DES COMMANDES   #
###########################

# --- TicketCloseView ---
# Une vue interactive qui ajoute un bouton "Close Ticket"
class TicketCloseView(discord.ui.View):
    def __init__(self, ticket_channel_id: int, owner_id: int):
        super().__init__(timeout=None)
        self.ticket_channel_id = ticket_channel_id
        self.owner_id = owner_id

    @discord.ui.button(label="Close Ticket", style=discord.ButtonStyle.danger, custom_id="ticket_close_button")
    async def close_ticket(self, interaction: discord.Interaction, button: discord.ui.Button):
        # Vérifie si l'utilisateur qui clique est autorisé (soit le créateur, soit un admin)
        if interaction.user.id != self.owner_id and not interaction.user.guild_permissions.administrator:
            await interaction.response.send_message("Vous n'êtes pas autorisé à fermer ce ticket.", ephemeral=True)
            return
        await interaction.response.send_message("Ticket fermé dans 5 secondes...", ephemeral=True)
        await asyncio.sleep(5)
        channel = interaction.channel
        if channel:
            await channel.delete()

# --- Cog de Gestion ---
class GestionCmd(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self.permissions = {}    # Pour stocker les niveaux de permission
        self.sniped_messages = []  # Pour stocker jusqu'à 10 messages supprimés
        self.active_tickets = {}   # Pour stocker les tickets actives (channel id -> owner_id)

    # Système de sniping : enregistre les messages supprimés
    @commands.Cog.listener()
    async def on_message_delete(self, message: discord.Message):
        if message.author.bot:
            return
        self.sniped_messages.insert(0, message)
        if len(self.sniped_messages) > 10:
            self.sniped_messages.pop()

    # ---------- Commandes Préfixées (+) ----------

    @commands.command()
    async def perm(self, ctx, level: int, user: discord.Member):
        """
        +perm <niveau> @user
        Attribue un niveau de permission (entre 1 et 5) à un utilisateur.
        """
        if 1 <= level <= 5:
            self.permissions[user.id] = level
            embed = discord.Embed(
                title="Permission Attribuée",
                description=f"{user.mention} reçoit le niveau `{level}` de permission.",
                color=discord.Color.green()
            )
            await ctx.send(embed=embed)
        else:
            embed = discord.Embed(
                title="Erreur",
                description="Le niveau doit être compris entre 1 et 5.",
                color=discord.Color.red()
            )
            await ctx.send(embed=embed)

    @commands.command()
    async def checkperm(self, ctx, user: discord.Member):
        """
        +checkperm @user
        Affiche le niveau de permission enregistré pour un utilisateur.
        """
        level = self.permissions.get(user.id, 0)
        embed = discord.Embed(
            title="Niveau de Permission",
            description=f"{user.mention} possède le niveau `{level}`.",
            color=discord.Color.blue()
        )
        await ctx.send(embed=embed)

    @commands.command()
    @commands.has_permissions(kick_members=True)
    async def kick(self, ctx, user: discord.Member, *, reason="Aucune raison"):
        """
        +kick @user [raison]
        Expulse un utilisateur du serveur.
        """
        try:
            await user.kick(reason=reason)
            embed = discord.Embed(
                title="Kick effectué",
                description=f"{user.mention} a été expulsé.\nRaison : {reason}",
                color=discord.Color.orange()
            )
            await ctx.send(embed=embed)
        except Exception as e:
            embed = discord.Embed(
                title="Erreur lors du Kick",
                description=str(e),
                color=discord.Color.red()
            )
            await ctx.send(embed=embed)

    @commands.command()
    @commands.has_permissions(ban_members=True)
    async def ban(self, ctx, user: discord.Member, *, reason="Aucune raison"):
        """
        +ban @user [raison]
        Bannit un utilisateur.
        """
        try:
            await user.ban(reason=reason)
            embed = discord.Embed(
                title="Ban effectué",
                description=f"{user.mention} a été banni.\nRaison : {reason}",
                color=discord.Color.orange()
            )
            await ctx.send(embed=embed)
        except Exception as e:
            embed = discord.Embed(
                title="Erreur lors du Ban",
                description=str(e),
                color=discord.Color.red()
            )
            await ctx.send(embed=embed)

    @commands.command()
    @commands.has_permissions(manage_messages=True)
    async def clear(self, ctx, count: int):
        """
        +clear <nombre>
        Supprime un nombre déterminé de messages (le message de commande est inclus).
        """
        try:
            deleted = await ctx.channel.purge(limit=count + 1)
            embed = discord.Embed(
                title="Clear",
                description=f"{len(deleted)-1} messages supprimés.",
                color=discord.Color.blurple()
            )
            await ctx.send(embed=embed, delete_after=5)
        except Exception as e:
            embed = discord.Embed(
                title="Erreur lors du Clear",
                description=str(e),
                color=discord.Color.red()
            )
            await ctx.send(embed=embed)

    @commands.command()
    @commands.has_permissions(manage_roles=True)
    async def addrole(self, ctx, user: discord.Member, role: discord.Role):
        """
        +addrole @user @role
        Ajoute un rôle à un utilisateur.
        """
        try:
            await user.add_roles(role)
            embed = discord.Embed(
                title="Rôle Ajouté",
                description=f"{user.mention} reçoit le rôle `{role.name}`.",
                color=discord.Color.green()
            )
            await ctx.send(embed=embed)
        except Exception as e:
            embed = discord.Embed(
                title="Erreur lors de l'ajout du Rôle",
                description=str(e),
                color=discord.Color.red()
            )
            await ctx.send(embed=embed)

    @commands.command()
    @commands.has_permissions(manage_roles=True)
    async def removerole(self, ctx, user: discord.Member, role: discord.Role):
        """
        +removerole @user @role
        Retire un rôle à un utilisateur.
        """
        try:
            await user.remove_roles(role)
            embed = discord.Embed(
                title="Rôle Retiré",
                description=f"{user.mention} n'a plus le rôle `{role.name}`.",
                color=discord.Color.green()
            )
            await ctx.send(embed=embed)
        except Exception as e:
            embed = discord.Embed(
                title="Erreur lors du retrait du Rôle",
                description=str(e),
                color=discord.Color.red()
            )
            await ctx.send(embed=embed)

    @commands.command()
    @commands.has_permissions(manage_roles=True)
    async def mute(self, ctx, user: discord.Member, *, reason="Aucune raison"):
        """
        +mute @user [raison]
        Mute un utilisateur en lui attribuant le rôle 'Muted'. Si le rôle n'existe pas, il est créé avec les permissions adaptées.
        """
        muted_role = discord.utils.get(ctx.guild.roles, name="Muted")
        if not muted_role:
            try:
                muted_role = await ctx.guild.create_role(name="Muted", reason="Création du rôle pour mute")
                # Appliquer le mute dans tous les salons
                for channel in ctx.guild.channels:
                    await channel.set_permissions(muted_role, send_messages=False, speak=False, add_reactions=False)
            except Exception as e:
                embed = discord.Embed(
                    title="Erreur durant la création du rôle Muted",
                    description=str(e),
                    color=discord.Color.red()
                )
                await ctx.send(embed=embed)
                return
        try:
            await user.add_roles(muted_role, reason=reason)
            embed = discord.Embed(
                title="Utilisateur Mute",
                description=f"{user.mention} a été mute.\nRaison : {reason}",
                color=discord.Color.orange()
            )
            await ctx.send(embed=embed)
        except Exception as e:
            embed = discord.Embed(
                title="Erreur lors du Mute",
                description=str(e),
                color=discord.Color.red()
            )
            await ctx.send(embed=embed)

    @commands.command()
    @commands.has_permissions(manage_roles=True)
    async def unmute(self, ctx, user: discord.Member):
        """
        +unmute @user
        Réactive la parole d'un utilisateur en retirant le rôle 'Muted'.
        """
        muted_role = discord.utils.get(ctx.guild.roles, name="Muted")
        if muted_role in user.roles:
            try:
                await user.remove_roles(muted_role)
                embed = discord.Embed(
                    title="Utilisateur Unmute",
                    description=f"{user.mention} peut de nouveau parler.",
                    color=discord.Color.green()
                )
                await ctx.send(embed=embed)
            except Exception as e:
                embed = discord.Embed(
                    title="Erreur lors de l'Unmute",
                    description=str(e),
                    color=discord.Color.red()
                )
                await ctx.send(embed=embed)
        else:
            embed = discord.Embed(
                title="Information",
                description=f"{user.mention} n'est pas mute.",
                color=discord.Color.blue()
            )
            await ctx.send(embed=embed)

    @commands.command()
    async def snipe(self, ctx, index: int = 1):
        """
        +snipe [index]
        Affiche l'un des 10 derniers messages supprimés (1 = dernier, 2 = avant-dernier, etc.).
        """
        if index < 1 or index > 10:
            embed = discord.Embed(
                title="Erreur",
                description="L'index doit être compris entre 1 et 10.",
                color=discord.Color.red()
            )
            await ctx.send(embed=embed)
            return
        try:
            message = self.sniped_messages[index-1]
        except IndexError:
            embed = discord.Embed(
                title="Snipe",
                description="Aucun message supprimé à cet index.",
                color=discord.Color.blue()
            )
            await ctx.send(embed=embed)
            return
        embed = discord.Embed(
            title="Message Supprimé",
            description=message.content if message.content else "[Pas de contenu]",
            color=discord.Color.blurple(),
            timestamp=message.created_at
        )
        if message.author.avatar:
            embed.set_author(name=message.author.display_name, icon_url=message.author.avatar.url)
        else:
            embed.set_author(name=message.author.display_name)
        await ctx.send(embed=embed)

    # ---------- Commandes Slash pour Ticket (avec bouton interactif) ----------

    @app_commands.command(name="ticket_create", description="Créer un ticket privé pour contacter le support.")
    async def ticket_create(self, interaction: discord.Interaction):
        guild = interaction.guild
        if guild is None:
            await interaction.response.send_message("Cette commande doit être utilisée dans un serveur.", ephemeral=True)
            return

        # Obtient ou crée la catégorie "Tickets"
        category = discord.utils.get(guild.categories, name="Tickets")
        if category is None:
            category = await guild.create_category("Tickets")

        # Définir les permissions : seul l'auteur et le rôle Support (si existant) peuvent voir le ticket
        overwrites = {
            guild.default_role: discord.PermissionOverwrite(read_messages=False),
            interaction.user: discord.PermissionOverwrite(read_messages=True, send_messages=True)
        }
        support_role = discord.utils.get(guild.roles, name="Support")
        if support_role:
            overwrites[support_role] = discord.PermissionOverwrite(read_messages=True, send_messages=True)

        ticket_channel = await guild.create_text_channel(f"ticket-{interaction.user.name}", category=category, overwrites=overwrites)
        self.active_tickets[ticket_channel.id] = interaction.user.id

        ticket_embed = discord.Embed(
            title="Ticket Ouvert",
            description=f"{interaction.user.mention}, votre ticket est créé.\nCliquez sur le bouton ci-dessous pour fermer le ticket lorsque vous avez terminé.",
            color=discord.Color.green()
        )
        view = TicketCloseView(ticket_channel_id=ticket_channel.id, owner_id=interaction.user.id)
        await ticket_channel.send(embed=ticket_embed, view=view)
        await interaction.response.send_message(f"Votre ticket a été créé : {ticket_channel.mention}", ephemeral=True)

    @app_commands.command(name="ticket_close", description="Ferme le ticket actuel.")
    async def ticket_close(self, interaction: discord.Interaction):
        channel = interaction.channel
        if channel is None or channel.id not in self.active_tickets:
            await interaction.response.send_message("Ce channel n'est pas un ticket.", ephemeral=True)
            return
        owner_id = self.active_tickets[channel.id]
        if interaction.user.id != owner_id and not interaction.user.guild_permissions.administrator:
            await interaction.response.send_message("Vous n'êtes pas autorisé à fermer ce ticket.", ephemeral=True)
            return
        await interaction.response.send_message("Fermeture du ticket dans 5 secondes...", ephemeral=True)
        await asyncio.sleep(5)
        await channel.delete()
        if channel.id in self.active_tickets:
            del self.active_tickets[channel.id]

# Fin du Cog

async def setup(bot: commands.Bot):
    await bot.add_cog(GestionCmd(bot))

###########################
#  EVENEMENTS & LANCEMENT  #
###########################

@bot.event
async def on_ready():
    print(f"🔌 Bot connecté en tant que {bot.user}")
    # Synchronisation des commandes slash
    try:
        synced = await bot.tree.sync()
        print(f"✅ {len(synced)} commandes slash synchronisées")
    except Exception as e:
        print("Erreur lors de la synchronisation des commandes slash:", e)

@bot.command(name="help")
async def custom_help(ctx):
    help_embed = discord.Embed(
        title="Commandes du Bot",
        description=(
            "**Préfixe (+) :**\n"
            "`+perm <niveau> @user` : Attribue une permission (1 à 5).\n"
            "`+checkperm @user` : Affiche la permission d'un utilisateur.\n"
            "`+kick @user [raison]` : Expulse un utilisateur.\n"
            "`+ban @user [raison]` : Bannit un utilisateur.\n"
            "`+clear <nombre>` : Supprime des messages.\n"
            "`+addrole @user @role` : Ajoute un rôle.\n"
            "`+removerole @user @role` : Retire un rôle.\n"
            "`+mute @user [raison]` : Mute un utilisateur.\n"
            "`+unmute @user` : Unmute un utilisateur.\n"
            "`+snipe [index]` : Affiche un message supprimé (index 1 à 10).\n\n"
            "**Slash Commands (/)**\n"
            "`/ticket_create` : Crée un ticket.\n"
            "`/ticket_close` : Ferme le ticket actuel."
        ),
        color=discord.Color.blurple()
    )
    await ctx.send(embed=help_embed)

# Récupère le token depuis la variable d'environnement (sur Replit, stocke-le dans "TOKEN")
TOKEN = os.getenv("MTM3Mzc5OTAzMTIxMzY1ODE0Mg.GswVRJ.c-_HA-WUf82AqHbXWwVXo5CRtIV6xXX7WndiNM")
if not TOKEN:
    print("Erreur : Aucun token trouvé dans les variables d'environnement.")
    exit()

# Lancement du bot
async def main():
    async with bot:
        # Charge le cog
        await setup(bot)
        await bot.start(MTM3Mzc5OTAzMTIxMzY1ODE0Mg.GswVRJ.c-_HA-WUf82AqHbXWwVXo5CRtIV6xXX7WndiNM)

asyncio.run(main())
