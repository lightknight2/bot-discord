
"""
Module py_cash - Utilitaires personnalisés pour le bot Discord
"""

def format_currency(amount):
    """Formate un montant en devise"""
    return f"{amount:,.2f}€"

def calculate_percentage(value, total):
    """Calcule un pourcentage"""
    if total == 0:
        return 0
    return (value / total) * 100

# Version du module
__version__ = "1.0.0"
