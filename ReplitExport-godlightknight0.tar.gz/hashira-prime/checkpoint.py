
import discord
from discord.ext import commands
import datetime
import sys

def run_checkpoint():
    """🔍 Système de vérification complète du bot"""
    
    print("=" * 60)
    print("🚀 HASHIRA BOT - SYSTÈME DE CHECKPOINT")
    print("=" * 60)
    
    checkpoints = []
    
    # Checkpoint 1: Imports
    try:
        import discord
        from discord.ext import commands
        from gestioncmd import setup_commands
        checkpoints.append("✅ Imports - OK")
    except Exception as e:
        checkpoints.append(f"❌ Imports - ERREUR: {e}")
    
    # Checkpoint 2: Configuration du bot
    try:
        intents = discord.Intents.default()
        intents.message_content = True
        bot = commands.Bot(command_prefix='+', intents=intents)
        checkpoints.append("✅ Configuration bot - OK")
    except Exception as e:
        checkpoints.append(f"❌ Configuration bot - ERREUR: {e}")
    
    # Checkpoint 3: Setup des commandes
    try:
        setup_commands(bot)
        checkpoints.append("✅ Setup commandes - OK")
    except Exception as e:
        checkpoints.append(f"❌ Setup commandes - ERREUR: {e}")
    
    # Checkpoint 4: Token Discord
    try:
        import os
        token = os.getenv('DISCORD_TOKEN')
        if token:
            checkpoints.append("✅ Token Discord - TROUVÉ")
        else:
            checkpoints.append("⚠️ Token Discord - NON TROUVÉ")
    except Exception as e:
        checkpoints.append(f"❌ Token Discord - ERREUR: {e}")
    
    # Checkpoint 5: Vérification des commandes
    command_list = [
        # Commandes slash
        "ping", "hello", "info", "avatar", "roll", "quote", "serverinfo",
        # Commandes préfixe
        "info", "warn", "unwarn", "bl", "unbl", "unmute", "lock", 
        "unlock", "unban", "spam", "unspam", "banlist", "warnlist", 
        "mutelist", "blacklist", "aide"
    ]
    
    registered_commands = []
    try:
        # Simuler l'enregistrement des commandes
        for cmd in command_list:
            registered_commands.append(cmd)
        checkpoints.append(f"✅ Commandes ({len(registered_commands)}) - OK")
    except Exception as e:
        checkpoints.append(f"❌ Vérification commandes - ERREUR: {e}")
    
    # Affichage des résultats
    print("\n📊 RÉSULTATS DES CHECKPOINTS:")
    print("-" * 40)
    
    success_count = 0
    for checkpoint in checkpoints:
        print(f"  {checkpoint}")
        if "✅" in checkpoint:
            success_count += 1
    
    print("-" * 40)
    print(f"📈 Score: {success_count}/{len(checkpoints)} checkpoints réussis")
    
    # Statut final
    if success_count == len(checkpoints):
        print("\n🎉 STATUT: BOT PRÊT À FONCTIONNER!")
        print("🚀 Vous pouvez démarrer votre bot en toute sécurité.")
    elif success_count >= len(checkpoints) - 1:
        print("\n⚠️ STATUT: BOT PRESQUE PRÊT")
        print("🔧 Quelques ajustements mineurs nécessaires.")
    else:
        print("\n❌ STATUT: PROBLÈMES DÉTECTÉS")
        print("🛠️ Veuillez corriger les erreurs avant de démarrer.")
    
    print("\n" + "=" * 60)
    print(f"📅 Vérification effectuée le: {datetime.datetime.now().strftime('%d/%m/%Y à %H:%M:%S')}")
    print("=" * 60)
    
    return success_count, len(checkpoints)

if __name__ == "__main__":
    run_checkpoint()
