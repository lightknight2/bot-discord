
# 🛠️ GUIDE DE DÉPANNAGE HASHIRA BOT

## 🔍 CHECKPOINT SYSTÈME

Pour vérifier votre bot, exécutez:
```bash
python3 checkpoint.py
```

## ✅ COMMANDES DISPONIBLES

### 🎮 Commandes Slash (/)
- `/ping` - Teste la latence
- `/hello` - Salutation stylée
- `/info` - Infos du bot
- `/avatar` - Avatar d'un utilisateur
- `/roll` - Dé personnalisable
- `/quote` - Citation inspirante
- `/serverinfo` - Infos du serveur

### ⚖️ Commandes Modération (+)
- `+warn @membre [raison]` - Avertir
- `+unwarn @membre` - Retirer avertissement
- `+bl @membre [raison]` - Blacklister
- `+unbl @membre` - Déblacklister
- `+unmute @membre` - Démuter
- `+lock [#salon]` - Verrouiller salon
- `+unlock [#salon]` - Déverrouiller salon
- `+unban <user_id>` - Débannir
- `+spam [message]` - Mode spam
- `+unspam` - Arrêter spam

### 📋 Commandes Liste (+)
- `+banlist` - Liste des bannis
- `+warnlist [@membre]` - Avertissements
- `+mutelist` - Liste des mutés
- `+blacklist` - Liste blacklistés
- `+aide` - Aide complète

## 🚨 PROBLÈMES COURANTS

### Bot ne répond pas
1. Vérifiez le token dans les Secrets
2. Vérifiez que le bot est invité sur le serveur
3. Permissions du bot correctes

### Commandes slash invisibles
1. Le bot doit être en ligne
2. Attendre la synchronisation (quelques minutes)
3. Redémarrer Discord si nécessaire

### Erreurs de permissions
1. Role du bot au-dessus des autres
2. Permissions administrateur activées
3. Permissions de salon correctes

## 🔧 MAINTENANCE

### Redémarrage complet
1. Arrêter le bot (bouton Stop)
2. Attendre 10 secondes
3. Relancer avec le bouton Run

### Vérification logs
Regardez la console pour les erreurs et messages de connexion.

## 📞 SUPPORT

Si problème persistant:
1. Exécutez `python3 checkpoint.py`
2. Vérifiez les logs d'erreur
3. Redémarrez le bot
4. Vérifiez les permissions Discord
