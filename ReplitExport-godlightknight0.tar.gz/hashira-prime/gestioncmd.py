import discord
from discord.ext import commands
from datetime import datetime, timedelta
import asyncio

# Création du bot avec tous les Intents
bot = commands.Bot(command_prefix="+", intents=discord.Intents.all())

# Variables pour stocker quelques états
blacklist = set()          # Stocke les ID des membres blacklistés
spamming = {}              # Stocke l'état du spam par salon
last_deleted = None        # Dernier message supprimé (pour +snipe)
derank_store = {}          # Sauvegarde des rôles pour derank/rerank (clé = ID utilisateur)
warns = {}                 # Sauvegarde des avertissements (clé = ID utilisateur)

# ---------------------------
# +help : Affiche toutes les commandes dans un embed stylé
# ---------------------------
@bot.command(name="help")
async def help_command(ctx):
    embed = discord.Embed(
        title="📜 Commandes du Bot",
        description="Liste complète des commandes disponibles :",
        color=0x00ff00
    )
    commands_list = {
        "🚀 +help": "Affiche la liste des commandes.",
        "🔇 +mute @user [durée]": "Mute un utilisateur (ex: 5H pour 5 heures, défaut = 28J).",
        "✅ +unmute @user": "Retire le mute d'un utilisateur.",
        "⚠️ +bl @user": "Blackliste un membre (il ne pourra plus rejoindre, même avec un alt).",
        "🏳️ +unbl @user": "Retire un membre de la blacklist.",
        "🔨 +ban [user/ID]": "Bannit un utilisateur du serveur (mention ou ID).",
        "🚪 +unban [ID]": "Débannit un utilisateur via son ID.",
        "📋 +list": "Affiche la liste des sanctions (blacklist, derank, warns).",
        "🚀 +kick @user": "Expulse un membre du serveur.",
        "🎨 +create": "Crée un autocollant à partir d'un GIF ou emoji.",
        "🔍 +snipe": "Affiche le dernier message supprimé.",
        "🗯️ +spam <texte>": "Spam un message toutes les 0,1 sec jusqu'à +unspam.",
        "🚫 +unspam": "Arrête le spam en cours.",
        "🎟️ +ticketpanel": "Ouvre le système de ticket pour contacter le staff.",
        "🧹 +clear <nombre>": "Supprime plusieurs messages (jusqu'à 100) dans le salon.",
        "🏷️ +addrole @user <rôle>": "Ajoute un rôle à un membre.",
        "❌ +delrole @user <rôle>": "Retire un rôle d'un membre.",
        "⬇️ +derank @user": "Retire tous ses rôles et les sauvegarde.",
        "⬆️ +rerank @user": "Restaure les rôles sauvegardés.",
        "⚠️ +warn @user <raison>": "Avertit un utilisateur.",
        "🏳️ +unwarn @user": "Retire un avertissement.",
        "🔒 +lock <salon>": "Verrouille un salon (empêche d'envoyer des messages).",
        "🔓 +unlock <salon>": "Déverrouille un salon."
    }
    for command, description in commands_list.items():
        embed.add_field(name=command, value=description, inline=False)
    await ctx.send(embed=embed)

# ---------------------------
# +mute : Mets un utilisateur en timeout pour une durée personnalisée
# ---------------------------
@bot.command(name="mute")
async def mute(ctx, member: discord.Member, duration: str = "28J"):
    # Mapping : S = secondes, M = minutes, H = heures, J = jours
    time_map = {"S": 1, "M": 60, "H": 3600, "J": 86400}
    unit = duration[-1].upper()
    try:
        amount = int(duration[:-1])
    except ValueError:
        await ctx.send("Format de durée invalide. Exemple : 5H ou 28J.")
        return
    if unit in time_map:
        seconds = amount * time_map[unit]
        until = datetime.utcnow() + timedelta(seconds=seconds)
        try:
            await member.edit(timeout=until)
            await ctx.send(f"{member.mention} est mute pour {duration} ⏳")
        except Exception as e:
            await ctx.send(f"Erreur lors du mute : {e}")
    else:
        await ctx.send("Unité de temps invalide. Utilise S, M, H ou J.")

# ---------------------------
# +unmute : Retire le timeout d'un utilisateur
# ---------------------------
@bot.command(name="unmute")
async def unmute(ctx, member: discord.Member):
    try:
        await member.edit(timeout=None)
        await ctx.send(f"{member.mention} est désormais unmute ✅")
    except Exception as e:
        await ctx.send(f"Erreur lors de l'unmute : {e}")

# ---------------------------
# +bl et +unbl : Ajoute ou retire un membre de la blacklist
# ---------------------------
@bot.command(name="bl")
async def bl(ctx, member: discord.Member):
    blacklist.add(member.id)
    await ctx.send(f"{member.mention} a été blacklisté. Il ne pourra plus rejoindre le serveur, même avec un alt.")

@bot.command(name="unbl")
async def unbl(ctx, member: discord.Member):
    if member.id in blacklist:
        blacklist.remove(member.id)
        await ctx.send(f"{member.mention} a été retiré de la blacklist.")
    else:
        await ctx.send(f"{member.mention} n'était pas blacklisté.")

# Bannissement automatique des membres blacklistés lors de leur arrivée
@bot.event
async def on_member_join(member):
    if member.id in blacklist:
        try:
            await member.ban(reason="Membre blacklisté.")
            print(f"{member} a été automatiquement banni (blacklist).")
        except Exception as e:
            print(f"Erreur lors du bannissement de {member} : {e}")

# ---------------------------
# +ban : Bannit un utilisateur (mention ou via ID)
# ---------------------------
@bot.command(name="ban")
async def ban(ctx, *, arg):
    try:
        member = None
        if ctx.message.mentions:
            member = ctx.message.mentions[0]
        else:
            member_id = int(arg.strip())
            member = ctx.guild.get_member(member_id)
        if member:
            await member.ban(reason=f"Ban par {ctx.author}")
            await ctx.send(f"{member.mention} a été banni 🔨")
        else:
            await ctx.send("Membre non trouvé.")
    except Exception as e:
        await ctx.send(f"Erreur lors du ban : {e}")

# ---------------------------
# +unban : Débannit un utilisateur via son ID
# ---------------------------
@bot.command(name="unban")
async def unban(ctx, *, arg):
    try:
        user_id = int(arg.strip())
        banned_users = await ctx.guild.bans()
        for ban_entry in banned_users:
            user = ban_entry.user
            if user.id == user_id:
                await ctx.guild.unban(user, reason=f"Unban par {ctx.author}")
                await ctx.send(f"{user.mention} a été débanni 🚪")
                return
        await ctx.send("Utilisateur non trouvé dans la liste des bans.")
    except Exception as e:
        await ctx.send(f"Erreur lors du unban : {e}")

# ---------------------------
# +list : Affiche la liste des sanctions dans un embed
# ---------------------------
@bot.command(name="list")
async def list_sanctions(ctx):
    embed = discord.Embed(title="📋 Liste des sanctions", color=0x3498db)
    embed.add_field(
        name="Membres blacklistés",
        value=", ".join(str(uid) for uid in blacklist) or "Aucun",
        inline=False
    )
    if derank_store:
        deranked = "\n".join(f"<@{uid}>: {roles}" for uid, roles in derank_store.items())
    else:
        deranked = "Aucun"
    embed.add_field(name="Membres derankés", value=deranked, inline=False)
    if warns:
        warn_list = "\n".join(f"<@{uid}>: {count} avertissement(s)" for uid, count in warns.items())
    else:
        warn_list = "Aucun"
    embed.add_field(name="Avertissements", value=warn_list, inline=False)
    await ctx.send(embed=embed)

# ---------------------------
# +kick : Expulse un membre du serveur
# ---------------------------
@bot.command(name="kick")
async def kick(ctx, member: discord.Member):
    try:
        await member.kick(reason=f"Kick par {ctx.author}")
        await ctx.send(f"{member.mention} a été expulsé 🚀")
    except Exception as e:
        await ctx.send(f"Erreur lors du kick : {e}")

# ---------------------------
# +create : (Dummy) Crée un autocollant à partir d'un GIF ou emoji
# ---------------------------
@bot.command(name="create")
async def create(ctx):
    await ctx.send("Commande +create non encore configurée pour créer un autocollant.")

# ---------------------------
# Snipe : Stocke et affiche le dernier message supprimé
# ---------------------------
@bot.event
async def on_message_delete(message):
    global last_deleted
    last_deleted = message

@bot.command(name="snipe")
async def snipe(ctx):
    if last_deleted:
        embed = discord.Embed(
            title="🔍 Dernier message supprimé",
            description=last_deleted.content,
            color=0xff0000
        )
        embed.set_author(
            name=last_deleted.author.display_name,
            icon_url=(last_deleted.author.avatar.url if last_deleted.author.avatar else None)
        )
        await ctx.send(embed=embed)
    else:
        await ctx.send("Aucun message supprimé récemment.")

# ---------------------------
# +spam et +unspam : Spam un message puis l'arrête
# ---------------------------
@bot.command(name="spam")
async def spam(ctx, *, content):
    channel_id = ctx.channel.id
    if spamming.get(channel_id, False):
        await ctx.send("Le spam est déjà en cours dans ce salon.")
        return

    async def spam_task():
        try:
            while spamming.get(channel_id, False):
                await ctx.send(content)
                await asyncio.sleep(0.1)
        except Exception as e:
            await ctx.send(f"Erreur lors du spam : {e}")

    spamming[channel_id] = True
    bot.loop.create_task(spam_task())
    await ctx.send("Spam démarré.")

@bot.command(name="unspam")
async def unspam(ctx):
    channel_id = ctx.channel.id
    spamming[channel_id] = False
    await ctx.send("Spam arrêté.")

# ---------------------------
# +ticketpanel : (Dummy) Système de ticket
# ---------------------------
@bot.command(name="ticketpanel")
async def ticketpanel(ctx):
    embed = discord.Embed(
        title="🎟️ Ticket Panel",
        description="Cliquez sur le bouton ci-dessous pour ouvrir un ticket.",
        color=0x00ff00
    )
    await ctx.send(embed=embed)
    await ctx.send("Système de ticket non entièrement configuré.")

# ---------------------------
# +clear : Supprime un nombre de messages (max 100)
# ---------------------------
@bot.command(name="clear")
async def clear(ctx, amount: int):
    try:
        await ctx.channel.purge(limit=amount)
        await ctx.send(f"{amount} messages supprimés 🧹", delete_after=5)
    except Exception as e:
        await ctx.send(f"Erreur lors du clear : {e}")

# ---------------------------
# +addrole et +delrole : Gère les rôles d'un utilisateur
# ---------------------------
@bot.command(name="addrole")
async def addrole(ctx, member: discord.Member, *, role: discord.Role):
    try:
        await member.add_roles(role)
        await ctx.send(f"{role.name} a été ajouté à {member.mention} 🏷️")
    except Exception as e:
        await ctx.send(f"Erreur lors de l'ajout du rôle : {e}")

@bot.command(name="delrole")
async def delrole(ctx, member: discord.Member, *, role: discord.Role):
    try:
        await member.remove_roles(role)
        await ctx.send(f"{role.name} a été retiré de {member.mention} ❌")
    except Exception as e:
        await ctx.send(f"Erreur lors de la suppression du rôle : {e}")

# ---------------------------
# +derank et +rerank : Supprime ou restaure les rôles d'un utilisateur
# ---------------------------
@bot.command(name="derank")
async def derank(ctx, member: discord.Member):
    try:
        roles = [r for r in member.roles if r != ctx.guild.default_role]
        derank_store[member.id] = [r.id for r in roles]
        await member.edit(roles=[ctx.guild.default_role])
        await ctx.send(f"{member.mention} a été deranké. Ses anciens rôles ont été sauvegardés.")
    except Exception as e:
        await ctx.send(f"Erreur lors du derank : {e}")

@bot.command(name="rerank")
async def rerank(ctx, member: discord