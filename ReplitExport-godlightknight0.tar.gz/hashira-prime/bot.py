import os
import discord
from discord.ext import tasks
import requests

# Importation du bot (et de ses commandes) depuis gestioncmd.py
from gestioncmd import bot

# Remplacez par l'URL publique de votre projet Replit pour le keep-alive
BOT_URL = "https://replit.com/@godlightknight0/hashira-prime?v=1"  # À modifier

# Boucle keep-alive : envoie un ping toutes les 5 minutes pour éviter la mise en veille
@tasks.loop(minutes=5)
async def keep_alive():
    try:
        requests.get(BOT_URL)
        print("Ping envoyé, le bot reste actif !")
    except Exception as e:
        print(f"Erreur lors du ping : {e}")

@bot.event
async def on_ready():
    print(f"{bot.user.name} est prêt ! ✅")
    keep_alive.start()

# Remplacez "TON_TOKEN_ICI" par le token de votre bot Discord
TOKEN = "MTM3Mzc5OTAzMTIxMzY1ODE0Mg.GMIVom.GciaCjMf8KZm05YLPCLODjsCMp7roy1bBdpvVU"
bot.run(TOKEN)
